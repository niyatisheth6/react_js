import logo from './logo.svg';
import './App.css';
import Raddit from './components/Raddit';

function App() {
  return (
  <Raddit/>
  );
}

export default App;
