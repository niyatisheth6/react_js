import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import CreateCard from "./CreateCard";
import { Link } from "react-router-dom";
import cardGetApi from "../api/cardGetApi";
import { Typography } from "@material-tailwind/react";
function DisplayData() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const fetchData = async (page, skip, limit) => {
    const response = await cardGetApi(page, skip, limit);
    return response.data.products;
  };

  const { data } = useQuery(
    ["products", currentPage, currentPage - 1, pageSize],
    () => fetchData(currentPage, (currentPage - 1) * pageSize, pageSize)
  );

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };
  return (
    <div className="container">
      <div>
        <h1 className="heading">Products Listing</h1>
      </div>
      <div className="flex justify-between mr-5">
        <div>
          <Link to="/card">
            <button className="btn">Add Data</button>
          </Link>
        </div>
        <div className="flex gap-3 justify-center items-center">
          <button
            className="btn"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Prev Page
          </button>
          <Typography color="gray" className="font-normal">
            Page <strong className="text-blue-gray-900">{currentPage}</strong> of{" "}
            <strong className="text-blue-gray-900">{pageSize}</strong>
          </Typography>
          <button className="btn" onClick={handleNextPage} disabled={currentPage === pageSize}>
            Next Page
          </button>
        </div>
      </div>
      <div className="data">
        {data &&
          data.map((obj, index) => {
            return (
              <React.Fragment key={index}>
                <CreateCard obj={obj} />
              </React.Fragment>
            );
          })}
      </div>
    </div>
  );
}

export default DisplayData;
