import React from "react";
import { useNavigate } from "react-router-dom";

function AllCard() {
  const navigate = useNavigate();
  return (
    <div className="grid col-span-3 gap-2 flex-wrap">
      <button className="btn" onClick={() => navigate("/display-data")}>
        1. DisplayData using usequery
      </button>
      <button className="btn" onClick={() => navigate("/pagination-1")}>
        2. Pagination using useEffect
      </button>
      <button className="btn" onClick={() => navigate("/pagination-2")}>
        3. Pagination 2 using useEffect
      </button>
      <button className="btn" onClick={() => navigate("/pagination-3")}>
        4. Pagination 3 using useQuery todo list
      </button>
      <button className="btn" onClick={() => navigate("/pagination-4")}>
        5. Pagination 4 using useQuery
      </button>
    </div>
  );
}

export default AllCard;
