import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import jasonGetApi from "../api/jasonGetApi";

function Pagination4() {
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const fetchProducts = async (page, skip, limit) => {
    const response = await jasonGetApi(page, skip, limit);
    return response.data.products;
  };

  const {
    data: products,
    isLoading,
    isError,
  } = useQuery(["products", currentPage, currentPage - 1, pageSize], () =>
    fetchProducts(currentPage, (currentPage - 1) * pageSize, pageSize)
  );

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };

  const handleNextPage = () => {
    setCurrentPage((prevPage) => prevPage + 1);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (isError) {
    return <div>Error occurred while fetching data.</div>;
  }

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {products.map((product) => (
          <div key={product.id} className="bg-white rounded shadow p-4">
            <h3 className="text-lg font-semibold">
              {product.id} {product.title}
            </h3>
          </div>
        ))}
      </div>

      <div className="flex justify-between items-center mt-4">
        <div>
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
          >
            Previous Page
          </button>
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={handleNextPage}
          >
            Next Page
          </button>
        </div>
      </div>
    </div>
  );
}

export default Pagination4;
